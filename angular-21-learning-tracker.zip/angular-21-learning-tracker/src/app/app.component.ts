import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

type TopicStatus = 'Not Started' | 'In Progress' | 'Completed' | 'Needs Revision';

interface RevisionEntry {
  date: string;
  note: string;
}

interface PracticeEntry {
  date: string;
  kind: string;
  note: string;
}

interface Topic {
  id: string;
  title: string;
  status: TopicStatus;
  note: string;
  revisions: RevisionEntry[];
  practice: PracticeEntry[];
}

interface Stage {
  id: number;
  title: string;
  description: string;
  topics: Topic[];
}

const topic = (id: string, title: string, status: TopicStatus = 'Not Started'): Topic => ({
  id, title, status, note: '', revisions: [], practice: []
});

const INITIAL_STAGES: Stage[] = [
  {
    id: 1, title: 'DI Fundamentals & Basics',
    description: 'Understand dependencies, services, tokens and how Angular injects them.',
    topics: [
      topic('s1-t1', 'What is Dependency Injection?', 'Completed'),
      topic('s1-t2', 'What is a Service?', 'Completed'),
      topic('s1-t3', '@Injectable()', 'Completed'),
      topic('s1-t4', 'inject() function', 'Completed'),
      topic('s1-t5', 'DI Tokens and InjectionToken', 'Completed')
    ]
  },
  {
    id: 2, title: 'Providers & Registration',
    description: 'Learn how to register dependencies and configure providers.',
    topics: [
      topic('s2-t1', 'What is a Provider?', 'Completed'),
      topic('s2-t2', 'providers vs viewProviders', 'Completed'),
      topic('s2-t3', "providedIn: 'root'", 'Completed'),
      topic('s2-t4', 'useClass', 'Completed'),
      topic('s2-t5', 'useValue', 'Completed'),
      topic('s2-t6', 'useFactory', 'Completed'),
      topic('s2-t7', 'useExisting', 'Completed'),
      topic('s2-t8', 'multi: true', 'Completed'),
      topic('s2-t9', 'deps', 'Completed')
    ]
  },
  {
    id: 3, title: 'Injector Hierarchy & Resolution',
    description: 'Understand injector scopes and how Angular resolves dependencies.',
    topics: [
      topic('s3-t1', 'Provider Resolution Hierarchy', 'Completed'),
      topic('s3-t2', 'Root Injector vs Platform Injector', 'Completed'),
      topic('s3-t3', 'Element Injector', 'Completed'),
      topic('s3-t4', 'Environment Injector Hierarchy and route providers', 'Completed')
    ]
  },
  {
    id: 4, title: 'Injection Modifiers',
    description: 'Control where Angular searches and what happens when a dependency is missing.',
    topics: [
      topic('s4-t1', 'Normal inject() resolution', 'Completed'),
      topic('s4-t2', 'Self modifier — self: true', 'Completed'),
      topic('s4-t3', 'SkipSelf modifier — skipSelf: true', 'Completed'),
      topic('s4-t4', 'Host modifier — host: true', 'Needs Revision'),
      topic('s4-t5', 'Optional modifier — optional: true', 'In Progress'),
      topic('s4-t6', 'Combining injection options', 'Not Started'),
      topic('s4-t7', 'Practical comparison and exercises', 'Not Started')
    ]
  },
  {
    id: 5, title: 'Advanced inject() & Injection Context',
    description: 'Use inject() safely in functional and advanced Angular APIs.',
    topics: [
      topic('s5-t1', 'What is an Injection Context?'),
      topic('s5-t2', 'Where can inject() be called?'),
      topic('s5-t3', 'runInInjectionContext()')
    ]
  },
  {
    id: 6, title: 'DI Best Practices, Testing & Debugging',
    description: 'Apply DI concepts in maintainable real-world Angular applications.',
    topics: [
      topic('s6-t1', 'Hierarchical DI best practices'),
      topic('s6-t2', 'Real-world Angular DI architecture'),
      topic('s6-t3', 'Testing services and providers'),
      topic('s6-t4', 'Debugging dependency injection errors')
    ]
  }
];

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  stages: Stage[] = structuredClone(INITIAL_STAGES);
  selectedStageId = 1;
  selectedTopicId = 's1-t1';
  newTopicTitle = '';
  revisionDate = new Date().toISOString().slice(0, 10);
  revisionNote = '';
  practiceDate = new Date().toISOString().slice(0, 10);
  practiceKind = 'Coding practice';
  practiceNote = '';
  storageMessage = 'Changes save automatically in this browser.';
  private readonly storageKey = 'angular21-di-tracker-v1';

  ngOnInit(): void {
    this.load();
  }

  get selectedStage(): Stage {
    return this.stages.find(stage => stage.id === this.selectedStageId) ?? this.stages[0];
  }

  get selectedTopic(): Topic {
    return this.findTopic(this.selectedTopicId) ?? this.selectedStage.topics[0];
  }

  get allTopics(): Topic[] {
    return this.stages.flatMap(stage => stage.topics);
  }

  get completedCount(): number {
    return this.allTopics.filter(item => item.status === 'Completed').length;
  }

  get totalCount(): number {
    return this.allTopics.length;
  }

  get progress(): number {
    return this.totalCount ? Math.round((this.completedCount / this.totalCount) * 100) : 0;
  }

  get inProgressCount(): number {
    return this.allTopics.filter(item => item.status === 'In Progress').length;
  }

  get revisionCount(): number {
    return this.allTopics.filter(item => item.status === 'Needs Revision').length;
  }

  get pendingCount(): number {
    return this.allTopics.filter(item => item.status === 'Not Started').length;
  }

  stageCompleted(stage: Stage): number {
    return stage.topics.filter(item => item.status === 'Completed').length;
  }

  stageProgress(stage: Stage): number {
    return stage.topics.length ? Math.round((this.stageCompleted(stage) / stage.topics.length) * 100) : 0;
  }

  selectStage(stageId: number): void {
    this.selectedStageId = stageId;
    const first = this.selectedStage.topics[0];
    if (first) this.selectedTopicId = first.id;
  }

  selectTopic(topicId: string): void {
    this.selectedTopicId = topicId;
  }

  updateStatus(value: string): void {
    const allowed: TopicStatus[] = ['Not Started', 'In Progress', 'Completed', 'Needs Revision'];
    if (allowed.includes(value as TopicStatus)) {
      this.selectedTopic.status = value as TopicStatus;
      this.save();
    }
  }

  updateNote(value: string): void {
    this.selectedTopic.note = value;
    this.save();
  }

  addTopic(): void {
    const title = this.newTopicTitle.trim();
    if (!title) return;
    const id = `custom-${this.selectedStageId}-${Date.now()}`;
    this.selectedStage.topics.push(topic(id, title));
    this.selectedTopicId = id;
    this.newTopicTitle = '';
    this.save();
  }

  deleteSelectedTopic(): void {
    const stage = this.selectedStage;
    if (stage.topics.length <= 1) return;
    const index = stage.topics.findIndex(item => item.id === this.selectedTopicId);
    if (index < 0) return;
    stage.topics.splice(index, 1);
    this.selectedTopicId = stage.topics[Math.max(0, index - 1)].id;
    this.save();
  }

  addRevision(): void {
    if (!this.revisionDate) return;
    this.selectedTopic.revisions.unshift({
      date: this.revisionDate,
      note: this.revisionNote.trim()
    });
    this.revisionNote = '';
    this.save();
  }

  addPractice(): void {
    if (!this.practiceDate || !this.practiceNote.trim()) return;
    this.selectedTopic.practice.unshift({
      date: this.practiceDate,
      kind: this.practiceKind,
      note: this.practiceNote.trim()
    });
    this.practiceNote = '';
    this.save();
  }

  save(): void {
    localStorage.setItem(this.storageKey, JSON.stringify({
      stages: this.stages,
      selectedStageId: this.selectedStageId,
      selectedTopicId: this.selectedTopicId
    }));
    this.storageMessage = 'Saved just now in this browser.';
  }

  exportBackup(): void {
    const blob = new Blob([JSON.stringify({
      exportedAt: new Date().toISOString(),
      stages: this.stages
    }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'angular-21-learning-tracker-backup.json';
    anchor.click();
    URL.revokeObjectURL(url);
  }

  importBackup(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as { stages?: Stage[] };
        if (!Array.isArray(parsed.stages) || parsed.stages.length === 0) {
          throw new Error('Invalid backup');
        }
        this.stages = parsed.stages;
        this.selectedStageId = this.stages[0].id;
        this.selectedTopicId = this.stages[0].topics[0]?.id ?? '';
        this.save();
        this.storageMessage = 'Backup imported successfully.';
      } catch {
        this.storageMessage = 'Could not import that file. Please choose a tracker JSON backup.';
      }
      input.value = '';
    };
    reader.readAsText(file);
  }

  private findTopic(id: string): Topic | undefined {
    return this.stages.flatMap(stage => stage.topics).find(item => item.id === id);
  }

  private load(): void {
    const raw = localStorage.getItem(this.storageKey);
    if (!raw) return;
    try {
      const parsed = JSON.parse(raw) as {
        stages?: Stage[];
        selectedStageId?: number;
        selectedTopicId?: string;
      };
      if (Array.isArray(parsed.stages) && parsed.stages.length) this.stages = parsed.stages;
      if (parsed.selectedStageId) this.selectedStageId = parsed.selectedStageId;
      if (parsed.selectedTopicId && this.findTopic(parsed.selectedTopicId)) {
        this.selectedTopicId = parsed.selectedTopicId;
      } else {
        this.selectedTopicId = this.selectedStage.topics[0]?.id ?? '';
      }
    } catch {
      this.storageMessage = 'Saved data could not be read. A fresh tracker is loaded.';
    }
  }
}