# Angular 21 Learning Tracker

A standalone Angular 21 learning dashboard with stage-wise topics, status tracking, notes, revision history, practice logs, and JSON backup/restore.

## Important privacy note

- Topic progress, notes, revisions, and practice logs are stored in the browser's `localStorage`.
- They are not uploaded to GitHub by this app.
- Browser storage is local to the browser profile/device. Use **Export backup** regularly to keep a JSON backup.
- GitHub Pages is public by default, even when its source repository is private. Private GitHub Pages access control requires GitHub Enterprise Cloud and an organization-owned repository. Do not deploy personal notes to a public site if private access is required.

## Run locally

Requirements: Node.js 22+ and npm.

```bash
npm install
npm start
```

Open the local URL shown by Angular CLI (usually http://localhost:4200).

## Create a private GitHub repository

1. Sign in to GitHub.
2. Create a new repository named `angular-21-learning-tracker`.
3. Select **Private** visibility.
4. Do not enable a README, `.gitignore`, or license during creation (this project already contains them).
5. On your computer, extract this ZIP and open a terminal in the extracted folder.
6. Run:

```bash
git init
git add .
git commit -m "Initial Angular 21 learning tracker"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/angular-21-learning-tracker.git
git push -u origin main
```

Replace `YOUR_GITHUB_USERNAME` with your GitHub username.

## Hosting choices

### Truly private GitHub Pages

GitHub's private Pages access control requires GitHub Enterprise Cloud and an organization-owned repository. If you have that setup, enable Pages in repository Settings and choose **Private** visibility.

### Personal GitHub account

A private repository alone does **not** make the published Pages website private. If you enable ordinary GitHub Pages, visitors may access the website without signing into GitHub. The app's notes remain in each visitor's local browser storage, but the site itself is public. Do not choose this if you require a private URL.

For personal-only use without Enterprise Cloud, run the app locally, or choose a hosting service with authentication/access control before publishing.

## GitHub Pages workflow

The included `.github/workflows/deploy.yml` builds and deploys the app when `main` is updated. Only enable this workflow after confirming that the Pages visibility is appropriate for your privacy requirement.

In GitHub:
1. Open repository **Settings → Pages**.
2. Set **Build and deployment → Source** to **GitHub Actions**.
3. Push to `main`; then check the **Actions** tab for the deployment.
4. The published URL appears in the workflow deployment and Settings → Pages.

## Roadmap seed data

The app starts with the six-stage DI roadmap and the learning statuses discussed in the study conversation. You can change any status, edit notes, add custom topics, record revisions, and log practice.
